#Please go through the step defs and other important files incase the project doesn't build or work

# Automated Testing

## Setup

`npm install`

**Windows**

`npm run wdu:win`

**Mac**  
`npm run wdu`

`npm run fix-memory-limit`

## Available commands

| Command         | Description  |
|---              |---          |
| npm install | Install all dependencies |
| npm test | Runs the automated tests |
| npm run wdu:win | Runs 'webdriver-manager update' on Windows |
| npm run wds:win | Runs 'webdriver-manager start' on Windows |

## Running using local browser

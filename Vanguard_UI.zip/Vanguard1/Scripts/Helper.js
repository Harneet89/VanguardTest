const DEFAULT_LOCAL_BROWSER_CONFIG = 'browsers.local.chrome.json';

function checkRequiredEnvVars() {
    if (!process.env.CUKE_TAGS) {
        throw new Error('Environment variable CUKE_TAGS must be defined');
    }
    if (!process.env.CUKE_ENV) {
        throw new Error('Environment variable CUKE_ENV must be defined');
    }
}

function getCapabilities() {
    let browserConfig = DEFAULT_LOCAL_BROWSER_CONFIG;

    console.log(`Using browser config: ${browserConfig}`);
    return require(`../test-config/browsers/${browserConfig}`);
}

function siteHostPrefix() {
    if (process.env.CUKE_ENV === 'local') {
        return "https://www.vanguardinvestments.com.au"
    }

    return `https://vanguardinvestment-${process.env.CUKE_ENV}-.com.au`
}

function getRunTags() {
    let runTags = process.env.CUKE_TAGS;
    console.log('Running tag is: ' + runTags);
    return runTags;

}
module.exports = {
    siteHostPrefix: siteHostPrefix,
    getRunTags: getRunTags,
};

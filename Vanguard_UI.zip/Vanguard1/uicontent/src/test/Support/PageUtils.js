var q = require('q');
const helper = require('../../../scripts/helper');
/**
 * this is for page actions and other webdriver related calls rather than expectations
 */
var api = {
    configureBrowser: configureBrowser, // called in each page object
    waitForDisplayed: waitForDisplayed,
    waitForPresent: waitForPresent,
    waitFor: waitFor,
    consoleLog: consoleLog,
};

function configureBrowser(browser, environment) {

    if (browser.params.context.isChrome()) {
        console.log("Chrome Exec");
        //Set browser maximize position first
        browser.driver.manage().window().setPosition(0, 0);

        //Increase window size based on screen resolution
        browser.driver.executeScript(function () {
            return {
                width: window.screen.availWidth,
                height: window.screen.availHeight
            };
        }).then(function (result) {
            browser.driver.manage().window().setSize(result.width, result.height);
        });
    } else {
        console.log("Device Emulation is set to false");
        browser.manage().window().maximize();
    }
}

function waitForPresent(elementFinder, timeout) {
    return waitForPromiseCheck(elementFinder, 'isPresent',
        function (result) {
            //console.log(result)
            return result;
        }, timeout);
}

function waitForDisplayed(elementFinder, timeout) {
    return waitForPresent(elementFinder, timeout).then(function () {
        return waitForPromiseCheck(elementFinder, 'isDisplayed',
            function (result) {
                return result;
            }, timeout);
    });
}

function waitFor(expectedCondition, timeout) {
    if (!timeout) timeout = 50000;
    return browser.wait(expectedCondition, timeout, 'timed out waiting for expectedCondition - is the locator correct?');
}

function clickElement(element) {
    return waitForClickable(element).then(function () {
        annotate('clicking element', element);
        return element.click();
    });
}

function isDisplayed(element) {
    return element.isDisplayed().then(function (displayed) {
        annotate('isDisplayed ' + displayed, element);
        return displayed;
    }, function (err) {
        if (err.name === 'NoSuchElementError') {
            annotate('Error: NoSuchElement: ', element);
            return false;
        }
        return err;
    });
}


function consoleLog(...args) {
    return new Promise((resolve) => {
        console.log.apply(this, args);
    resolve(true);
});
}
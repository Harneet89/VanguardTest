/**
 * @class Base page object for Vanguard - not used directly
 */
var VanguardInvestmentBase = function VanguardInvestmentBase() {

    // get some environment config, and configure browser
    var environment = browser.params.environment.nab;
    var pageUtils = require('/Users/p772823/IdeaProjects/nab_automation_framework/src/test/e2e/PageUtils.js');


    pageUtils.configureBrowser(browser, environment);
    browser.ignoreSynchronization = true;

    // common navigation targets for scenario keywords

    // default url
    this.url = '/';

    // load page
    this.get = function () {
        var that = this;

        return browser.driver.get(environment.siteHostPrefix + "/")
            .then(function() {
                console.log("url value - ",(environment.siteHostPrefix + that.url));
                return browser.get(environment.siteHostPrefix + that.url);
            });
    };

    // default element to check page is loaded
    this.loadCheck = element(by.css('body'));

    this.waitForLoaded = function () {
        return pageUtils.waitForPageLoad(this.loadCheck, environment.maxPageLoadTime);
    };

    return this;
};

module.exports = VanguardInvestmentBase;


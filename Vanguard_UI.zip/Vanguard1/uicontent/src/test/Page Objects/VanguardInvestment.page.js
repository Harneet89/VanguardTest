var VANguardInvestment = function VANguardInvestment() {
    // inherit from the base page
    this.__proto__ = require('./VanguardInvestment.base.page.js')();

    // page url
    this.url = '/au/portal/homepage.jsp';

    // element to check page is loaded
    this.loadCheck = element(by.cssContainingText('title','Low-cost managed funds and ETFs'));

    // targets for scenario keywords
    this.individualandSmsfInvestorLink = element(by.css('.grid4 .hideOnSml [href=\'/retail/jsp/home.jsp\']'));
    this.individualAndSmsfInvestor = element(by.css('#vgn-globalHeader .vgn-container [aria-haspopup=\'true\'] .vgn-siteIndicatorMenu.vgn-dropDownLabel'));
    //this.fundCompareLink = element(by.linkText('Fund compare'));
    //this.fundCompareLink = element(by.linkText('.link a','Fund compare'));
    this.fundCompareLink = element.all(by.css('.media-body .link')).first();
    this.compareProducts = element(by.css('.compareTableBgImg'));
    //this.addFundsButton = element.all(by.id('addButton0')).first();
    this.addFundsButton = element.all(by.css('button#addButton0')).get(1);
    this.fundTextBox = element.all(by.css('.addFundBox input#fundInput0')).get(0);
    //this.addfundButton = element(by.css('#selectorRow button#addButton0'));
    this.retailRadioButton = element(by.css('[type=\'radio\'][value=\'RETAIL\']'));
    this.fundCheckBox1Button = element(by.name('F0AUS05TJA'));
    this.fundCheckBox2Button = element(by.name('F0AUS05F3X'));
    this.fundCheckBox3Button = element(by.name('F0AUS05K3H'));
    this.fundCheckBox4Button = element(by.name('F0AUS05K31'));
    this.compareFundsButton = element(by.id('compareFundBtn'));
    this.productFacts = element(by.css('#body #main #sectionHead [colspan=\'9\']'));


};

module.exports = {
    "class": VANguardInvestment,
    name: 'Vanguard Investment'
};


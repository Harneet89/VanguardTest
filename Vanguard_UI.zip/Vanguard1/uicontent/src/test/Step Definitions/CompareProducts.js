
//In case we need the total number of rows on the page use tableLength
//var tableLength = document.getElementById('compareTableResults').querySelectorAll('tr').length

//Below Step Definition is written for compare products based on Fund Size

var tr = document.getElementById('compareTableResults').querySelectorAll('tr');
var td = [];
for(var i=1; i<10;i++){
    for(var j = 1; j <5;j ++){
        if(i === 9){
            var value = tr[i].querySelectorAll("td")[j].innerHTML;
            if(value.indexOf('billion') > -1){
                value = value.substring(value.indexOf('$')+1,value.indexOf('billion'))
            }else{
                value = value.substring(value.indexOf('$')+1,value.indexOf('million')).trim();
            }

            td[j-1] = value;
        }

    }

}
console.log(td.sort(function(a, b){return a < b}));

var {When, Then} = require('cucumber');
var q = require('q');
var Eyes = require('eyes.selenium').Eyes;
this.eyes = new Eyes();

var browserName = "Chrome";
var browserVersion = "Latest";

When(/^I click the "([^"]*)"(?: )?(link|button|drop down list|tab|field|element|) of the (home loan borrowing capacity|home loan enquiry|) form$/, function (elementName, elementType, formType) {

    var elementType = this.transform.elementTypeToVariableName(elementType);
    var el = this.transform.stringToVariableName(elementName + elementType);
    console.log("The form type is: ", formType);
    var that = this;
    that.pageUtils.scrollToElement(this.currentPage[el]);


    if ((browser.params.context.browserName == browserName  {

        if ((browser.params.context.browserVersion == browserVersion) {
            console.log("Click mein..");
            return that.pageUtils.clickElement(that.currentPage[el]);
        }
        else {
            //return that.currentPage[that.el].isPresent();
            console.log("Display mein..");
            return that.pageUtils.isDisplayed(that.currentPage[el]);

        }
    }
});

Then(/^I (?:should be on|reach|am taken to) the "([^"]*)" results page$/, function (pageName) {
    if (browser.params.context.browserName == browserName)  {
        if (browser.params.context.browserVersion == browserVersion) {
            this.currentPage = new this.pageObjectMap[pageName];
            return this.currentPage.waitForLoaded().then(function () {
                return browser.driver.executeScript("window.focus();");
            });
        }
        else {
            return browser.driver.sleep(1000);
        }
    }
});


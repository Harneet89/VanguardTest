var {Given} = require('cucumber');

Given(/^I (?:should be on|reach|am taken to) a new (?:window|tab)?$/, function () {
    if (!browser.params.context.isIPad() && !browser.params.context.isMobile()) {
        console.log("Running on desktop");
        browser.driver.sleep(5 * 1000);
        return browser.getAllWindowHandles().then(function (handles) {
            browser.driver.sleep(5 * 1000); // todo - prefer wait over sleep
            // todo, do we want to fail here if the handles.length is 0 ?
            console.log('Length= ' + handles.length);
            browser.switchTo().window(handles[handles.length - 1]).then(function () {
                console.log("Window switched successfully");
                browser.driver.executeScript("window.focus();");


            });
        });
    }

});
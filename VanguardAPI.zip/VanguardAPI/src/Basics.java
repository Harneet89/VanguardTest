import io.restassured.RestAssured;
import sourceValues.resource;

import java.io.FileReader;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import sourceValues.ReusableMethods;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Basics {

	Properties prop = new Properties();
	@BeforeTest
	public void getData() throws IOException
	{
		FileInputStream fis = new FileInputStream("D:\\Selenium Workspace\\VanguardAPI\\src\\sourceValues\\env.properties");
		prop.load(fis);
		
	}
	
	@Test
	public void NavPriceArray()
	{
		// TODO Auto-generated method stub
           
		RestAssured.baseURI=prop.getProperty("Host");
	    Response res =	given().
	                    when().get(resource.placeGetData()).
	                    then().
	                   // assertThat().statusCode(200).and().contentType(ContentType.JSON).
	                    extract().response();
	                   JsonPath js = ReusableMethods.rawToJson(res);
	
	String responseString = res.asString();
	System.out.println(responseString);

	
	 /*       JSONParser parser = new JSONParser();
	        JSONObject navObject = (JSONObject) parser.parse(new FileReader(resource.placeGetData()));
	        System.out.println(navObject.get("portId"));
	        System.out.println(navObject.get("navPriceArray").getClass().getName());
	        JSONArray jsonArray= (JSONArray) navObject.get("navPriceArray");

	        for(int i=0; i<jsonArray.size(); i++){
	            System.out.println(jsonArray.get(i)); */
	        }
	    }
	
	          
	


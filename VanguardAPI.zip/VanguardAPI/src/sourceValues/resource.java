package sourceValues;

public class resource {
	
	public static String placeGetData()
	{
		String res = "/retail/mvc/getNavPriceList.jsonp";
		return res;
	}

}
